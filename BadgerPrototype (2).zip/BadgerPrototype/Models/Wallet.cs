﻿using System.ComponentModel.DataAnnotations;

namespace BadgerPrototype.Models
{
    public class Wallet
    {
        public string WalletID { get; set; }

        [Display(Name = "Employee")]
        //must make emp id but using email for now
        public string EmpID { get; set; }
        public string BadgeID { get; set; }

        [Display(Name = "Earned badges")]
        public int BadgeCount { get; set; }

        public ICollection<Badge> Badges { get; set; }

        public Wallet()
        {

        }
    }
}
