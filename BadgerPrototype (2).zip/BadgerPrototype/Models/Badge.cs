﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity;

using System.ComponentModel.DataAnnotations;

namespace BadgerPrototype.Models
{
    public class Badge
    {
        [Key]
        public int BadgeID { get; set; }


        public enum Category
        {
            Birthday, Excellence, Integrity, Collaboration, Timeliness
        }
        public string Reason { get; set; }
        public string Sender { get; set; }
        public string Recipient { get; set; }

        [Display(Name = "Category for Badge")]
        public Category CategorySelected { get; set; }

        public string? Comment { get; set; }

        public Employee Employee { get; set; }
        public Wallet Wallet { get; set; }

        public Badge() 
        {

        }
    }
}
