﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity;

namespace BadgerPrototype.Models
{
    public class Employee
    {

        public string EmployeeId { get; set; }
        public string Name { get; set; }
        public string Surname { get; set; }
        public string Email { get; set; }
        public string Phone { get; set; }
        public string Position { get; set; }

        [Display(Name = "Birthday")]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:dd MMMM}", ApplyFormatInEditMode = true)]
        public DateTime DateOfBirth { get; set; }
        public string Password { get; set; }

        public ICollection<Badge> Badges { get; set; }

        public Employee()
        {

        }

    }
}
