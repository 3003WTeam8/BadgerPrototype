﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity;
using System.ComponentModel.DataAnnotations;

namespace BadgerPrototype.Models
{
    public class Merchandise

    {
        [Display(Name = "Merchandise item")]
        public int MerchandiseID { get; set; }

        [Display(Name = "Available")]
        public int MerchCount { get; set; }

        [Display(Name = "Badges needed")]
        public decimal MerchValue { get; set; }

        public Merchandise()
        {

        }
    }
}
