﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using BadgerPrototype.Models;

namespace BadgerPrototype.Data
{
    public class ApplicationDbContext : IdentityDbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }
        public DbSet<BadgerPrototype.Models.Employee> Employee { get; set; }
        public DbSet<BadgerPrototype.Models.Badge> Badge { get; set; }
        public DbSet<BadgerPrototype.Models.Merchandise> Merchandise { get; set; }
        public DbSet<BadgerPrototype.Models.Wallet> Wallet { get; set; }
    }
}